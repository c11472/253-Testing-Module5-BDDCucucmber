package com.sdet_Session001P2_SeleniumBDD.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SecondPage_AwesomeQA {
	
	WebDriver driver;
	
	By firstNm = By.name("firstname");
	
	public void initpage2(WebDriver driver) {
		this.driver = driver;
	}
	
	
	public String Open_RegistrationPage() {
		driver.get("https://awesomeqa.com/ui/index.php?route=account/register");
		
		String pgtitle2 = driver.getTitle();
		
		return pgtitle2;
		
	}
	
	public void Enter_First_Name() {
		
	}
	
	

}
