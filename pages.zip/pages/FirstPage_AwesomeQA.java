package com.sdet_Session001P2_SeleniumBDD.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FirstPage_AwesomeQA {
	
WebDriver driver;
	
	By phn = By.xpath("//*[contains(text(),'123456789')]");
	
	
	public void initpage1(WebDriver driver) {
		this.driver = driver;
		
	}
	
	public String Extract_PhoneNumber() {
		
		String Phone_Number = driver.findElement(phn).getText();
		
		System.out.println("The phone number is : " + Phone_Number);
		
		return Phone_Number;	
	}
	
	

}
